from django import forms
from .models import Users, Comments
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm

GENDER_CHOICES = (
    ('MALE', 'Male'),
    ('FEMALE', 'Female')
)
Districts = (
    ('Anantapur', 'Anantapur'),
    ('Chittoor', 'Chittoor'),
    ('East Godavari', 'East Godavari'),
    ('Guntur', 'Guntur'),
    ('Kadapa', 'Kadapa'),
    ('Krishna', 'Krishna'),
    ('Kurnool', 'Kurnool'),
    ('Sri Potti Sri Ramulu Nellore', 'Sri Potti Sri Ramulu Nellore'),
    ('Prakasam', 'Prakasam'),
    ('Srikakulam', 'Srikakulam'),
    ('Visakhapatnam', 'Visakhapatnam'),
    ('Vizianagaram', 'Vizianagaram'),
    ('West Godavari', 'West Godavari'),
)
class VideoSearchForm(forms.Form):
    search = forms.CharField(max_length=100)

class UserRegistrationForm(forms.ModelForm):
    username = forms.CharField(widget=forms.TextInput(
        attrs={
            'class': 'form-control',
            'placeholder': 'User Name'
        }
    ))
    password = forms.CharField(widget=forms.PasswordInput(
        attrs={
            'class': 'form-control',
            'placeholder': 'Password'
        }
    ))

    gender = forms.ChoiceField(choices=GENDER_CHOICES, widget=forms.RadioSelect(
        attrs={
            'class' : 'form-check-input',
        }
    ))
    email = forms.EmailField(widget=forms.TextInput(
        attrs={
            'class': 'form-control',
            'placeholder': 'Email',

        }
    ))
    phone_number = forms.CharField(widget=forms.TextInput(
        attrs={
            'class': 'form-control',
            'placeholder': 'Phone'
        }
    ))
   
    location = forms.ChoiceField(choices=Districts)
    class Meta:
        model = Users
        fields = ['username', 'email', 'password']

    
class CreateUserForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']
        
# class CommentForm(forms.ModelForm):
#     class Meta:
#         model = Comments
#         fields = ['username', 'video', 'describe']