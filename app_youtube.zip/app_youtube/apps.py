from django.apps import AppConfig


class AppYoutubeConfig(AppConfig):
    name = 'app_youtube'
