from django.shortcuts import render, get_object_or_404, redirect
from .models import Users, Videos, Comments, Likes, Dislikes, UserViews
from .forms import VideoSearchForm,  CreateUserForm, UserRegistrationForm
from django.contrib import messages
from django.db.models import Q
from django.views.generic import ListView
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
import pandas as pd
import pickle
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
import joblib

# Create your views here.

def index(request):
    videos = Videos.objects.all()
    paginator = Paginator(videos, 8)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    return render(request, 'index.html', {'page_obj': page_obj})

def home(request):
    videos = Videos.objects.all()
    paginator = Paginator(videos, 8)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    return render(request, 'index.html', {'page_obj': page_obj})

def video_open(request, video_id):
    
    user1 = request.session['username'] 
    user = Users.objects.get(username=user1)
    open_video = get_object_or_404(Videos, pk=video_id)
    #user = get_object_or_404(Users, pk=user1)
    videos = Videos.objects.all()
    view_videos = UserViews.objects.all()
   
    
    if request.method == 'POST':
        comment = request.POST.get('commenttt')
        df= pd.read_csv("data/YoutubeSpamMergedData.csv")
        df_data = df[["CONTENT","CLASS"]]
        # Features and Labels
        df_x = df_data['CONTENT']
        df_y = df_data.CLASS
        # Extract Feature With CountVectorizer
        corpus = df_x
        cv = CountVectorizer()
        X = cv.fit_transform(corpus) # Fit the Data
        from sklearn.model_selection import train_test_split
        X_train, X_test, y_train, y_test = train_test_split(X, df_y, test_size=0.33, random_state=42)
        #Naive Bayes Classifier
        from sklearn.naive_bayes import MultinomialNB
        clf = MultinomialNB()
        clf.fit(X_train,y_train)
        clf.score(X_test,y_test)
        data = [comment]
        vect = cv.transform(data).toarray()
        my_prediction = clf.predict(vect)
        if 0 in my_prediction:
            cm = Comments.objects.create(
            video = open_video,
            username = user,
            describe = request.POST.get('commenttt'),
            post_date = '2020-04-10'
            )
            cm.save()
        else:
            messages.info(request, 'Spam Comment')
            print("Spam Comment")
    
    return render(request, 'video_open.html', {
        'open_video':open_video,
        'videos': videos,
        'view_videos': view_videos,
        # 'videos': videos,
        'post_active': True
    })
    

def video_like(request, videos_id):
    videos = get_object_or_404(Videos, pk=videos_id)
    like = videos.like_video
    Videos.objects.filter(pk=videos_id).update(like_video = like+1)
    return redirect('/home/'+str(videos_id)+'/')

def video_dislike(request, videos_id):
    videos = get_object_or_404(Videos, pk=videos_id)
    dislike = videos.dislike_video
    Videos.objects.filter(pk=videos_id).update(dislike_video = dislike+1)
    return redirect('/home/'+str(videos_id)+'/')

# search video

def video_search(request):
    keyword = request.GET.get('q')
    hasil = Videos.objects.filter(title__contains=keyword)
    return render(request, 'searchpage.html', {'videos': hasil, 'keyword': keyword})

def registerPage(request):
    if request.user.is_authenticated:
        return redirect('app_youtube:index')
    else:
        form = UserRegistrationForm(request.POST)
        if request.method == 'POST':
            form = UserRegistrationForm(request.POST)
            #form = Users(request.POST)
            if form.is_valid():
                form.save()
                user = form.cleaned_data.get('username')
                messages.success(request, 'account was created for' + user)
                return redirect('app_youtube:login')
        context = {'form': form}
        return render(request, 'accounts/register.html', context)

def loginPage(request):
    if request.user.is_authenticated:
        return redirect('app_youtube:index')
    else:
        if request.method == "POST":
            username = request.POST.get('username')
            password = request.POST.get('password')
            print(username)
            print(password)
            print('----------')
            try:
                user = Users.objects.get(username=username, password=password)
                request.session['userid'] = user.id
                request.session['username'] = user.username
                print(user.username)
                print(user.password)
            except:
                messages.add_message(request, messages.ERROR, "Invalid Login")
                
            if user is not None:
                return redirect('app_youtube:home')
                #login(request, user)
                
            else:
                messages.info(request, 'username or password is incorrect')
        
        context = {}
        return render(request, 'accounts/login.html', context)

def logoutUser(request):
    logout(request)
    return redirect('app_youtube:login')

